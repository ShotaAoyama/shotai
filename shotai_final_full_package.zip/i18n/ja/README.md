# 🧠 Shotai: AIの「上に立つ」新しい自己拡張型プログラミング言語

Shotaiは、既存のプログラミング言語で対応できないリクエストを自動で判定し、新たな構文（Shotage）を生成する自己拡張型のAI上位言語です。

---

## 📂 プロジェクト構成

```
/shotai
├── README.md                # 英語版（本体）
├── LICENSE                  # Apache 2.0 ライセンス
├── docs/                    # 仕様・構文・哲学・収益モデル
│   ├── philosophy.md
│   ├── shotai-language.md
│   ├── security-policy.md
│   ├── security-incident.md
│   ├── ethics.md
│   └── revenue-model.md
├── i18n/                    # 翻訳フォルダ
│   ├── ja/                  # 日本語
│   ├── zh/                  # 中国語
│   ├── ru/                  # ロシア語
│   └── fr/                  # フランス語
├── manifests/               # 各国版マニフェスト（.docx）
```

---

## 🖋 発案者

- **名前**：青山 将大 (Shota Aoyama)
- **拠点**：東京、日本
- **発表日**：2025年5月7日

---

## 🤝 コントリビューター募集中

このプロジェクトはただの言語ではなく、思想です。  
あなたの貢献をお待ちしています。
